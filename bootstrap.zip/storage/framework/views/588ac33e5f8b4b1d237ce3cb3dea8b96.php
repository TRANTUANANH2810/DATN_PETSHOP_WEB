<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Đăng nhập trang quản trị
     <?php $__env->endSlot(); ?>
    <div class="flex justify-center mt-16 h-full">
        <div class="sm:max-w-lg sm:w-full sm:mx-auto">
            <div class="bg-white border border-gray-200 rounded-2xl shadow-lg">
                <div class="p-6 sm:p-8">
                    <!-- Header -->
                    <div class="text-center">
                        <h2 class="text-3xl font-bold text-gray-900">Quản trị viên Pet Spa</h2>
                        <p class="mt-2 text-sm text-gray-600">Đăng nhập vào tài khoản quản trị của bạn</p>
                    </div>

                    <!-- Form -->
                    <div class="mt-8">
                        <form method="post" action="<?php echo e(route('admin.signin.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="space-y-6">
                                <!-- Username Input -->
                                <div>
                                    <label for="username" class="block text-sm font-medium text-gray-700">Tên đăng nhập</label>
                                    <div class="mt-1 relative">
                                        <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>"
                                               class="py-3 px-4 block w-full border border-gray-300 rounded-lg text-sm shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                               placeholder="Nhập tên đăng nhập" required autofocus>
                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Password Input -->
                                <div>
                                    <label for="password" class="block text-sm font-medium text-gray-700">Mật khẩu</label>
                                    <div class="mt-1 relative">
                                        <input type="password" id="password" name="password"
                                               class="py-3 px-4 block w-full border border-gray-300 rounded-lg text-sm shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                               placeholder="Nhập mật khẩu" required>
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div>
                                    <button type="submit" class="w-full py-3 px-4 flex justify-center items-center text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Đăng nhập</button>
                                </div>
                                <!-- Quản trị viên? -->
                                <div class="text-sm text-center mt-6">
                                    <p class="text-gray-500">Bạn là nhân viên Pet Spa? <a href="<?php echo e(route('staff.signin')); ?>" class="text-blue-600 font-medium hover:underline">Đăng nhập tại đây</a></p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Petshop\resources\views/admins/signin.blade.php ENDPATH**/ ?>