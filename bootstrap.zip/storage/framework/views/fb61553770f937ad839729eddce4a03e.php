<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Danh\xampp_8_2\htdocs\Petshop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>