<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>" class="flex items-center justify-center mt-7">

        <div class="sm:flex-1 sm:flex sm:items-center sm:justify-center">
            <div>
                <span id="paginate" class="relative z-0 inline-flex rtl:flex-row-reverse gap-1">
                    <?php
                        $pageInfo = [
                            'previousPage' => $paginator->currentPage() > 1 ? $paginator->currentPage() - 1 : null,
                            'nextPage' => $paginator->currentPage() < $paginator->lastPage() ? $paginator->currentPage() + 1 : null,
                            'firstPage' => 1,
                            'lastPage' => $paginator->lastPage(),
                        ];
                    ?>
                    
                    <?php if(!$paginator->onFirstPage()): ?>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex justify-center items-center px-2 py-2 text-sm border border-gray-300 bg-gray-300 rounded-lg hover:bg-gray-400 w-8 h-8 transition ease-in-out duration-150" aria-label="<?php echo e(__('pagination.previous')); ?>">
                            <
                        </a>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <span aria-current="page">
                                        <span class="inline-flex justify-center items-center px-2 py-2 border-blue-500 bg-amber-400 text-sm border <?php echo e($role == 'staff' ? 'border-primary bg-primary' : 'border-primary-user bg-primary-user'); ?> rounded-lg w-8 h-8 transition ease-in-out duration-150"><?php echo e($page); ?></span>
                                    </span>
                                <?php elseif(in_array($page, $pageInfo)): ?>
                                    <a href="<?php echo e($url); ?>" class="inline-flex justify-center items-center px-2 py-2 text-sm border border-gray-300 bg-gray-300 rounded-lg hover:bg-gray-400 w-8 h-8 transition ease-in-out duration-150" aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>">
                                        <?php echo e($page); ?>

                                    </a>
                                <?php elseif(in_array($page - 1, $pageInfo)): ?>
                                    <span aria-disabled="true">
                                        <span class="inline-flex justify-center items-center px-2 py-2 text-sm border border-gray-300 bg-gray-300 rounded-lg hover:bg-gray-400 w-8 h-8 transition ease-in-out duration-150">...</span>
                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex justify-center items-center px-2 py-2 text-sm border border-gray-300 bg-gray-300 rounded-lg hover:bg-gray-400 w-8 h-8 transition ease-in-out duration-150" aria-label="<?php echo e(__('pagination.next')); ?>">
                            >
                        </a>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Petshop\resources\views/layouts/pagination.blade.php ENDPATH**/ ?>