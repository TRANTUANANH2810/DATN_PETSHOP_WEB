<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Xác thực địa chỉ Email')); ?></div>

                <div class="card-body">
                    <?php if(session('verified')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Xác thực tài khoản thành công! Bạn có thể đăng nhập.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Trước khi truy cập, vui lòng xác thực gửi qua email của bạn.')); ?>

                    <?php echo e(__('Nếu không nhận được email')); ?>,
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('Click vào đây để thử lại')); ?></button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Petshop\resources\views/auth/verify.blade.php ENDPATH**/ ?>