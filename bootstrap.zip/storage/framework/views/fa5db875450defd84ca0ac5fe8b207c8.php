<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Cập nhật thông tin pet
     <?php $__env->endSlot(); ?>
    <div>
        <div class="font-bold text-2xl text-center"> Cập nhật thông tin Pet</div>
        <div class="flex flex-col mt-5">
            <div class="-m-1.5 overflow-x-auto [&::-webkit-scrollbar]:h-1 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-blue-300">
                <form id="updateBlog" action="<?php echo e(route('admin.pets.update', $pet->id)); ?>" method="POST" class="md:w-4/5 md:m-auto mx-5 border-2 py-4 px-10 rounded-lg" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mt-7">
                        <label for="name" class="block text-sm mb-2 font-semibold">Tên chủ Pet</label>
                        <input id="name" name="name" value="<?php echo e($pet->name); ?>" class="p-2 border-2 block w-full border-blue-200 focus:border-blue-200 focus:ring-2 outline-none rounded-lg " placeholder="Nhập tên chủ Pet">
                    </div>

                    <!-- SDT -->
                    <div class="mt-7">
                        <label for="phone" class="block text-sm mb-2 font-semibold">Số điện thoại</label>
                        <input id="phone" name="phone" value="<?php echo e($pet->phone); ?>" class="p-2 border-2 block w-full  border-blue-200 focus:border-blue-200 focus:ring-2 outline-none rounded-lg " placeholder="Nhập số điện thoại">
                    </div>

                    <div class="mt-7">
                        <label for="image" class="block text-sm mb-2 font-semibold">Hình ảnh</label>
                        <div class="relative">
                            <input type="file" name="image" id="input-image" class="hidden">
                            <div id="image-preview-contain" class="w-96 h-64 flex items-center justify-center cursor-pointer">
                                <img id="image-preview" class="w-full h-full rounded-xl border-2 " src="<?php echo e(Storage::url($pet->image->path)); ?>" alt="">
                            </div>
                        </div>
                    </div>

                    <!-- Mô tả tình trạng -->
                    <div class="mt-7">
                        <label for="description" class="block text-sm mb-2 font-semibold">Tình trạng</label>
                        <textarea id="description" name="description" class="px-4 block w-full border-gray-200 rounded-lg placeholder-gray-400"><?php echo e($pet->description); ?></textarea>
                    </div>
                    <div class="flex justify-center mt-7">
                        <button id="editpet" type="submit" class="py-3 px-4 w-36 mb-5 inline-flex justify-center font-bold items-center gap-x-2 rounded-full border border-transparent bg-green-500 text-white hover:bg-green-700 cursor-pointer">
                            Cập nhật
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
     <?php $__env->slot('script', null, []); ?> 
        <script type="module">
            CKEDITOR.replace('description' , {
                height: 500,
                toolbar: [
                    '/',
                    ['Bold', 'Italic', 'Underline', 'StrikeThrough', '-', 'Undo', 'Redo', '-', 'Cut', 'Copy', 'Paste', 'Find', 'Replace', '-', 'Outdent', 'Indent', '-', 'Print'],
                    '/',
                    ['NumberedList', 'BulletedList', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'],
                    ['FontSize', 'Image', 'Table', '-', 'Link', 'Flash', 'Smiley', 'TextColor', 'BGColor', 'Source']
                ],
                fontSize_sizes: '12/12px;14/14px;16/16px;18/18px;24/24px;36/36px;48/48px;'
            });
            $(document).ready(function () {
                window.appConfig = {
                    urls: {
                        pet: '<?php echo e(route('admin.pets.index')); ?>',
                    },
                    values: {
                        role: '',
                    },
                    csrfToken: '<?php echo e(csrf_token()); ?>'
                };
            })
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

<?php /**PATH C:\Danh\xampp_8_2\htdocs\Petshop\resources\views/admins/pets/edit.blade.php ENDPATH**/ ?>