<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Doanh thu
     <?php $__env->endSlot(); ?>
    <div class="container">
        <h2 class="text-center my-4">Báo cáo Doanh thu từ Đơn hàng Đã giao</h2>

        <!-- Khu vực chọn thời gian -->
        <div class="row mb-4">
            <div class="col-md-4 offset-md-4">
                <form action="<?php echo e(route('admin.revenue')); ?>" method="GET" id="time-period-form">
                    <!-- Chọn theo tháng -->
                    <select id="time-period" name="timePeriod" class="form-select" aria-label="Chọn thời gian" onchange="document.getElementById('time-period-form').submit()">
                        <option value="monthly" <?php echo e($timePeriod == 'monthly' ? 'selected' : ''); ?>>Theo ngày trong tháng</option>
                        <option value="yearly" <?php echo e($timePeriod == 'yearly' ? 'selected' : ''); ?>>Theo tháng trong năm</option>
                    </select>
                    <!-- Chọn tháng -->
                    <input type="month" id="selected-month" name="selectedMonth" value="<?php echo e($selectedMonth ?? now()->format('Y-m')); ?>" class="form-control mt-3" onchange="document.getElementById('time-period-form').submit()">
                </form>
            </div>
        </div>

        <!-- Biểu đồ doanh thu -->
        <canvas id="revenueChart" class="w-96" height="200"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Dữ liệu biểu đồ được truyền từ controller
        const labels = <?php echo json_encode($labels, 15, 512) ?>;
        const data = <?php echo json_encode($totals, 15, 512) ?>;
        const orderCounts = <?php echo json_encode($orderCounts, 15, 512) ?>;

        const ctx = document.getElementById('revenueChart').getContext('2d');
        const revenueChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Doanh thu (không tính phí ship)',
                    data: data,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    title: {
                        display: true,
                        text: 'Biểu đồ Doanh thu theo Thời gian'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const index = context.dataIndex;
                                const revenue = context.raw.toLocaleString() + ' VND';
                                const orders = orderCounts[index];
                                return `Doanh thu: ${revenue}, Số đơn hàng: ${orders}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Thời gian'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Doanh thu (VNĐ)'
                        },
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Petshop\resources\views/admins/revenue.blade.php ENDPATH**/ ?>